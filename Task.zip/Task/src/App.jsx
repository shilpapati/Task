import React from 'react'
import Register from "./Auth/Register"
import Userdata from "./Components/Userdata.jsx"
import Nav from './Nav/Nav'
import { BrowserRouter as Router,Routes,Route } from 'react-router-dom'
function App() {
  return (
    <div>
        <Router>
          <Routes>
            <Route path='/' element={<Nav/>}/>
            <Route path='/Register' element={<Register/>}/>
             <Route path='/userdata' element={<Userdata/>}/>
          </Routes>
        </Router>
    </div>
  )
}

export default App
