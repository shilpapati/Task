import React from 'react'
import imgs from "../img/logo.png"
import { Link } from 'react-router-dom'
import "../home.css"
const Nav = () => {
  return (
    <nav>
      <div className='logo'>
        <img src={imgs} alt="" height={75} width={150} />
      </div>
      <div className='menu'>
        <ul>
            <li><Link to={"/"}>HOME</Link></li>
            <li><Link to={"/userdata"}>USERDATA</Link></li>
            <li><Link to={"/Register"}>REGISTER</Link></li>

        </ul>
      </div>
    </nav>
  )
}

export default Nav