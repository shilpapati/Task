import React, { useState, useEffect } from 'react';
import style from "./style.module.css"
import Nav from '../Nav/Nav';
const Register = () => {
    const [data, setData] = useState([]);
    const [newData, setnewData] = useState({
        userName: "",
        email: "",
        password: "",
        conpassword: "",
        phone: ""
    });
    let { userName, email, password, conpassword, phone } = newData;
    useEffect(() => {
        const storedData = JSON.parse(localStorage.getItem('data'));
        if (storedData) {
            setData(storedData);
        }
    }, []);

    // Update localStorage whenever data data changes
    useEffect(() => {
        localStorage.setItem('data', JSON.stringify(data));
    }, [data]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setnewData({
            ...newData,
            [name]: value,
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        if (validate()) {
            setData([...data, newData]);
            setnewData({
                userName: "",
                email: "",
                password: "",
                conpassword: "",
                phone: ""
            });
        }
    };
    let validate = () => {
        if (!userName) {
            alert("UserName is Required")
            return false
        }
        else if (!email) {
            alert("email is Required")
            return false
        }
        else if (!password) {
            alert("password is Required")
            return false
        }
        else if (!conpassword) {
            alert("conpassword is Required")
            return false
        }
        else if (!phone) {
            alert("phone is Required")
            return false
        }
        else if(password.trim()!==conpassword.trim()){
            alert("Password should be same")
            return false
        }
        else 
        return true
    }
    return (
        <div>
            <Nav />
            <form onSubmit={handleSubmit}>
                <h2>Register Page </h2>
                <label htmlFor="userName">User Name :</label>
                <input type="text" name='userName' value={userName} onChange={handleChange} className={style.input} /><br /> <br />

                <label htmlFor="email">Email :</label>
                <input type="text" name='email' value={email} onChange={handleChange} className={style.input} /><br /> <br />

                <label htmlFor="password">Password :</label>
                <input type="password" name='password' value={password} onChange={handleChange} className={style.input} /> <br /> <br />

                <label htmlFor="conpassword">Confirm Password :</label>
                <input type="password" name='conpassword' value={conpassword} onChange={handleChange} className={style.input} /> <br /> <br />

                <label htmlFor="phone">Phone Number :</label>
                <input type="number" name='phone' value={phone} onChange={handleChange} className={style.input} /><br /> <br />

                <button type="submit">Submit</button>
            </form>
        </div>
    );
};

export default Register;
