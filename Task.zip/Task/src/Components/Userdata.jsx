import React, { useState } from 'react'
import Nav from '../Nav/Nav'
const Userdata = () => {
    let [searchTerm, setSearchTerm] = useState('')
    let x = window.localStorage.getItem("data")
    let a =JSON.parse(x)
   const filteredData=a.filter((item)=>
    item.userName.toLowerCase().includes(searchTerm.toLowerCase())||
    item.email.toLowerCase().includes(searchTerm.toLowerCase())||
    item.phone.includes(searchTerm)
   );

    return (
        <> <Nav />
            <div className='userdet'>
                <h2>USER DETAILS</h2>
                <input type="text" placeholder="Search...." onChange={(e)=>setSearchTerm(e.target.value)}  className='search'/>
                <div className="data">
                    {filteredData.map((x) => {
                        return (
                            <div className='databorder'>
                                <h1>{x.userName}</h1>
                                <h1>{x.phone}</h1>
                                <h1>{x.email}</h1>
                            </div>
                        )
                    })}
                </div>
            </div>
        </>
    )
}

export default Userdata