import {createRoot} from "react-dom/client"
import App from "./App"
createRoot(document.getElementById('root')).render(<App/>)


// import RR from "./RR"
// createRoot(document.getElementById('root')).render(<RR/>)

// import Reg from "./Reg"
// createRoot(document.getElementById('root')).render(<Reg/>)